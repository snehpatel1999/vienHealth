export const namedRoutes = {
  dashboard: {
    index: "/dashboard",
  },
};