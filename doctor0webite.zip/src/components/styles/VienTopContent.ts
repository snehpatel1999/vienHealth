import styled from 'styled-components';

const PromptDetail = styled.p`
  color: #697077;
  font-weight: 500 !important;
  display: block;
`;

export {  PromptDetail };
